package com.dicoding.picodiploma.loginwithanimation
import androidx.annotation.VisibleForTesting
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@VisibleForTesting(otherwise = VisibleForTesting.NONE)
suspend fun <T> Flow<T>.getOrAwaitValue(
    time: Long = 2,
    timeUnit: TimeUnit = TimeUnit.SECONDS,
    afterObserve: () -> Unit = {}
): T {
    var data: T? = null
    val latch = CountDownLatch(1)
    val job = GlobalScope.launch {
        val flow = take(1)
        flow.collect {
            data = it
            latch.countDown()
        }
    }

    try {
        afterObserve.invoke()

        if (!latch.await(time, timeUnit)) {
            throw TimeoutException("Flow value was never set.")
        }
    } finally {
        job.cancelAndJoin()
    }

    @Suppress("UNCHECKED_CAST")
    return data as T
}
