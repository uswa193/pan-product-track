package com.capstone.pan.data.pref

data class UserModelRegist (
    val name: String,
    val email: String,
    val password: String,
    )