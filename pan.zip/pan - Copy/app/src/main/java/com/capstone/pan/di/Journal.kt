package com.capstone.pan.di
import java.util.Date

data class Journal(
    val date: Date,
    val emotion: String,
    val note: String
)
