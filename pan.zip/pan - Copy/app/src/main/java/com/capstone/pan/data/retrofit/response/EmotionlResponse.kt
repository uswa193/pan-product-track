package com.capstone.pan.data.retrofit.response

import com.google.gson.annotations.SerializedName

data class EmotionlResponse(

	@field:SerializedName("emotion")
	val emotion: String? = null
)
